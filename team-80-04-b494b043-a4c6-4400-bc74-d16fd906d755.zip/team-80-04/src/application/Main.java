package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class Main extends Application {
    Stage projectStage;
    String title = "QuillQube - PersonalBugTracker";
    Connection connectToDatabase;
    static ListView<String> searchResults;

    @Override
    public void start(Stage primaryStage) throws Exception {
        projectStage = primaryStage;

        // Connect to the database using the SqliteConnection class
        connectToDatabase = SqliteConnection.Connector();
        if (connectToDatabase == null) {
            showErrorDialog("Database Connection Error", "Could not connect to the database.");
            System.exit(1);
        }

        // Load project names from the database
        List<String> projectNames = loadProjectNamesFromDatabase();
        

        startScreen(projectNames);
    }

    public void createNewProject() {
        CreateNewProject.showCreateNewProject(this);
    }

    public void createNewTicket(List<String> projectNames) {
        CreateNewTicket.showCreateNewTicket(this, projectNames);
    }

    public void showSavedTickets() {
        List<String> projectNames = loadProjectNamesFromDatabase();
        TicketList.showTicketList(this, projectNames);
    }

    public void showNewComment(List<String> ticketNames) {
        AddComments.showNewComment(this, ticketNames);
    }
    
    public void showSavedComments() {
        List<Comment> comments = loadCommentsFromDatabase();
        CommentsList.showCommentsList(this, comments);
    }

    void startScreen(List<String> projectNames) {
        // Home user interface
        StackPane stackPane = new StackPane();
        stackPane.setStyle("-fx-background-color: Lavender;");
        stackPane.setPadding(new Insets(10, 10, 10, 10));

        VBox homeBox = new VBox(10);
        homeBox.setSpacing(20);
        homeBox.setAlignment(Pos.TOP_CENTER);

        // Add an ImageView for the project-related image
        ImageView projectImage = new ImageView(getClass().getResource("/application/bugTrackerImage.png").toExternalForm());
        projectImage.setFitWidth(850);
        projectImage.setFitHeight(550);

        // Add a Text component for the welcome message
        Text welcomeText = new Text("Welcome to QuillQube");
        welcomeText.setStyle("-fx-font-size: 45px; -fx-font-family: 'ALGERIAN', 'cursive';");

        // Create a ComboBox for user selection
        ComboBox<String> userSelection = new ComboBox<>();
        userSelection.setStyle("-fx-font-size: 15px; -fx-font-family: 'Comic Sans MS';");
        userSelection.setPromptText("Let's get started! Choose an option:");
        userSelection.getItems().addAll(
                "Create New Project",
                "Project List",
                "Create New Ticket",
                "Show Saved Tickets",
                "Add Comments",
                "Show Saved Comments", // Added option to show saved comments
                "Exit"
        );

        // Define actions for the ComboBox selection
        userSelection.setOnAction(event -> {
            String selectedAction = userSelection.getValue();
            if (selectedAction != null) {
                switch (selectedAction) {
                    case "Create New Project":
                        createNewProject();
                        break;
                    case "Project List":
                        ProjectList.showProjectList(this);
                        break;
                    case "Create New Ticket":
                        createNewTicket(projectNames);
                        break;
                    case "Show Saved Tickets":
                        showSavedTickets();
                        break;
                    case "Add Comments":
                        showNewComment(loadTicketsNameFromDataBase());
                        break;
                    case "Show Saved Comments":
                        showSavedComments();
                        break;
                    case "Exit":
                        projectStage.close();
                        break;
                }
            }
        });

        homeBox.getChildren().addAll(welcomeText, userSelection);
        

        // Add components to the StackPane
        stackPane.getChildren().addAll(projectImage, homeBox);

        // Set up the scene and show it
        projectStage.setScene(new Scene(stackPane, 950, 600));
        projectStage.setTitle(title);
        projectStage.show();
    }

    @Override
    public void stop() throws Exception {
        if (connectToDatabase != null) {
            connectToDatabase.close();
        }
    }

    // Load project names from the database
    List<String> loadProjectNamesFromDatabase() {
        List<String> projectNames = new ArrayList<>();
        try {
            Statement statement = connectToDatabase.createStatement();
            String query = "SELECT name FROM projects";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                projectNames.add(resultSet.getString("name"));
            }
            resultSet.close();
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return projectNames;
    }

    List<String> loadTicketsNameFromDataBase() {
        List<String> ticketNames = new ArrayList<>();
        try {
            Statement statement = connectToDatabase.createStatement();
            String query = "SELECT title FROM tickets";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                ticketNames.add(resultSet.getString("title"));
            }
            resultSet.close();
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ticketNames;
    }


    List<Comment> loadCommentsFromDatabase() {
        List<Comment> comments = new ArrayList<>();
        try {
            Statement statement = connectToDatabase.createStatement();
            String query = "SELECT ticket_name, comment, timestamp FROM Comments";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String ticketName = resultSet.getString("ticket_name");
                String comment = resultSet.getString("comment");
                Timestamp timestamp = resultSet.getTimestamp("timestamp");

                Comment newComment = new Comment(ticketName, comment, timestamp);
                comments.add(newComment);
            }
            resultSet.close();
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return comments;
    }
    
    // Helper method to display error dialogs
    private void showErrorDialog(String title, String content) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
