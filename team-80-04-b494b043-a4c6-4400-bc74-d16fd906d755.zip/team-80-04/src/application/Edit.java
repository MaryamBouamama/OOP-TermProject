package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Edit {

    private static void updateCommentInDatabase(String newComment, String ticketName, String oldComment, TableView<Comment> commentsTableView) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:quillqube.db")) {
            String query = "UPDATE Comments SET comment = ?, timestamp = CURRENT_TIMESTAMP WHERE ticket_name = ? AND comment = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, newComment);
                preparedStatement.setString(2, ticketName);
                preparedStatement.setString(3, oldComment);

                @SuppressWarnings("unused")
				int affectedRows = preparedStatement.executeUpdate();
                System.out.println("");

                // Update the corresponding item in the TableView
                Comment updatedComment = commentsTableView.getSelectionModel().getSelectedItem();
                if (updatedComment != null) {
                    updatedComment.setComment(newComment);
                    commentsTableView.refresh();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                System.err.println("Failed to update comment in the database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Failed to connect to the database.");
        }
    }

    public static void showEditComment(Comment selectedComment, TableView<Comment> commentsTableView) {
        VBox editBox = new VBox(10);

        // Create UI components for editing the comment
        TextArea editedCommentArea = new TextArea(selectedComment.getComment());
        Button saveButton = new Button("Save");

        saveButton.setOnAction(event -> {
            // Update the comment in the database
            updateCommentInDatabase(editedCommentArea.getText(), selectedComment.getTicketName(), selectedComment.getComment(), commentsTableView);

            // Close the edit window
            Stage stage = (Stage) saveButton.getScene().getWindow();
            stage.close();
        });

        editBox.getChildren().addAll(new Label("Edit Comment:"), editedCommentArea, saveButton);

        Stage editStage = new Stage();
        editStage.setScene(new Scene(editBox, 300, 200));
        editStage.setTitle("Edit Comment");
        editStage.show();
    }
}
