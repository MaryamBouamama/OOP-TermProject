package application;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableView;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Optional;

public class Delete {
	
    public static void deleteTicket(Ticket ticket, TableView<Ticket> ticketTable) {
        // Display a confirmation dialog
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Deletion");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to delete this ticket?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            // User clicked OK, proceed with deletion
            // Delete the ticket from the database
            deleteTicketFromDatabase(ticket);

            // Remove the ticket from the TableView
            ticketTable.getItems().remove(ticket);
        }
    }

    private static void deleteTicketFromDatabase(Ticket ticket) {
        // Use the connection from SqliteConnection
        try (Connection connection = SqliteConnection.Connector()) {
            if (connection != null) {
                // Implement the logic to delete the ticket from the database based on title
                String deleteQuery = "DELETE FROM Tickets WHERE title = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
                    preparedStatement.setString(1, ticket.getTitle());
                    preparedStatement.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void showDeleteConfirmation(Comment selectedComment, TableView<Comment> commentsTableView) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Confirmation");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to delete this comment?");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                // User clicked OK, proceed with deletion
                deleteCommentFromDatabase(selectedComment);
                commentsTableView.getItems().remove(selectedComment); // Update TableView
            }
        });
    }

    private static void deleteCommentFromDatabase(Comment comment) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:quillqube.db")) {
            String query = "DELETE FROM Comments WHERE ticket_name = ? AND comment = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, comment.getTicketName());
                preparedStatement.setString(2, comment.getComment());

             
               
            } catch (SQLException e) {
                e.printStackTrace();
                System.err.println("Failed to delete comment from the database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Failed to connect to the database.");
        }
    }


}
