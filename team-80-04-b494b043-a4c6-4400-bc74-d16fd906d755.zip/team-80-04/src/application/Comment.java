package application;

import java.sql.Timestamp;

public class Comment {
    private String ticketName;
    private String comment;
    private Timestamp timestamp;

    public Comment(String ticketName, String comment, Timestamp timestamp) {
        this.ticketName = ticketName;
        this.comment = comment;
        this.timestamp = timestamp;
    }

    public String getTicketName() {
        return ticketName;
    }

    public String getComment() {
        return comment;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setComment(String newComment) {
        this.comment = newComment;
    }


    public int getId() {
    	int id = 1;
		return id;

	}
}