package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Ticket {
    private final StringProperty title;
    private final StringProperty description;
    private final StringProperty projectName;

    public Ticket(String title, String description, String projectName) {
        this.title = new SimpleStringProperty(title);
        this.description = new SimpleStringProperty(description);
        this.projectName = new SimpleStringProperty(projectName);
    }

    public String getTitle() {
        return title.get();
    }

    public StringProperty titleProperty() {
        return title;
    }

    public void setTitle(String title) {
        this.title.set(title);
    }

    public String getDescription() {
        return description.get();
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    public void setDescription(String description) {
        this.description.set(description);
    }

    public String getProjectName() {
        return projectName.get();
    }

    public StringProperty projectNameProperty() {
        return projectName;
    }
}
