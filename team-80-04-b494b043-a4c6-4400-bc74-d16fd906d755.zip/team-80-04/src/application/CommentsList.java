package application;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Timestamp;
import java.util.List;

public class CommentsList {

    @SuppressWarnings("unchecked")
    public static void showCommentsList(Main main, List<Comment> comments) {
        // Create a VBox to display the TableView
        VBox commentsBox = new VBox(10);
        commentsBox.setStyle("-fx-background-color: Lavender; -fx-font-size: 12px; -fx-font-family: 'Comic Sans MS';");

        // Create a TableView to display comments
        TableView<Comment> commentsTableView = new TableView<>();

        // Create TableColumn for each property of Comment
        TableColumn<Comment, String> ticketColumn = new TableColumn<>("Ticket Name");
        TableColumn<Comment, String> commentColumn = new TableColumn<>("Comment");
        TableColumn<Comment, Timestamp> timestampColumn = new TableColumn<>("Timestamp");

        // Set up cell value factories
        ticketColumn.setCellValueFactory(new PropertyValueFactory<>("ticketName"));
        commentColumn.setCellValueFactory(new PropertyValueFactory<>("comment"));
        timestampColumn.setCellValueFactory(new PropertyValueFactory<>("timestamp"));
        
        // Set the column resize policy to automatically resize based on available space
        commentsTableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Add columns to the TableView
        commentsTableView.getColumns().addAll(ticketColumn, commentColumn, timestampColumn);

        // Populate the TableView with data
        commentsTableView.getItems().addAll(comments);


        // Set up buttons for edit and delete
        Button editButton = new Button("Edit");
        Button deleteButton = new Button("Delete");

        editButton.setOnAction(event -> handleEdit(main, commentsTableView));
        deleteButton.setOnAction(event -> handleDelete(main, commentsTableView));

        // Set up a button to go back to the main screen
        Button backButton = new Button("Back");
        backButton.setOnAction(event -> main.startScreen(main.loadProjectNamesFromDatabase()));

        // Add components to the VBox
        HBox buttonBox = new HBox(10, editButton, deleteButton);
        commentsBox.getChildren().addAll(commentsTableView, buttonBox, backButton);
        commentsBox.setPadding(new Insets(20, 20, 20, 20));

        // Set up the scene and show it
        Stage commentsStage = new Stage();
        commentsStage.setScene(new Scene(commentsBox, 600, 400));
        commentsStage.setTitle("Saved Comments");
        commentsStage.show();
    }

    private static void handleEdit(Main main, TableView<Comment> commentsTableView) {
        Comment selectedComment = commentsTableView.getSelectionModel().getSelectedItem();
        if (selectedComment != null) {
            Edit.showEditComment(selectedComment, commentsTableView);
        } else {
            showAlert("No comment selected", "Please select a comment to edit.");
        }
    }

    private static void handleDelete(Main main, TableView<Comment> commentsTableView) {
        Comment selectedComment = commentsTableView.getSelectionModel().getSelectedItem();
        if (selectedComment != null) {
            Delete.showDeleteConfirmation(selectedComment, commentsTableView);
        } else {
            showAlert("No comment selected", "Please select a comment to delete.");
        }
    }

    private static void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}