package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class TicketList {
    private static boolean searchPerformed = false;
    private static boolean editOrDeleteOccurred = false;

    @SuppressWarnings("unchecked")
    public static void showTicketList(Main main, List<String> projectNames) {
        VBox ticketListBox = new VBox(10);
        ticketListBox.setStyle("-fx-background-color: Lavender; -fx-font-size: 12px; -fx-font-family: 'Comic Sans MS';");
      //  ticketListBox.setAlignment(Pos.TOP_RIGHT);

        TableView<Ticket> ticketTable = new TableView<>();
        TableColumn<Ticket, String> ticketTitleColumn = new TableColumn<>("Ticket title");
        TableColumn<Ticket, String> projectColumn = new TableColumn<>("Project Name");
        TableColumn<Ticket, String> descriptionColumn = new TableColumn<>("Description");
        TableColumn<Ticket, Void> editColumn = new TableColumn<Ticket, Void>("Edit");
        TableColumn<Ticket, Void> deleteColumn = new TableColumn<Ticket, Void>("Delete");


        ticketTitleColumn.setCellValueFactory(cellData -> cellData.getValue().titleProperty());
        projectColumn.setCellValueFactory(cellData -> cellData.getValue().projectNameProperty());
        descriptionColumn.setCellValueFactory(cellData -> cellData.getValue().descriptionProperty());


        int buttonWidth = 170; // Adjust the width as needed


        editColumn.setPrefWidth(150);
        deleteColumn.setPrefWidth(150);

        editColumn.setCellFactory(param -> new TableCell<Ticket, Void>() {
            private final Button editButton = new Button("Edit");

            {
                editButton.setMinWidth(buttonWidth);
                editButton.setMaxWidth(buttonWidth);

                editButton.setOnAction(event -> {
                    Ticket selectedTicket = getTableView().getItems().get(getIndex());
                    showEditAndDeleteOptions(selectedTicket, ticketTable, main);
                    
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(editButton);
                }
            }
        });

        deleteColumn.setCellFactory(param -> new TableCell<Ticket, Void>() {
            private final Button deleteButton = new Button("Delete");

            {
                deleteButton.setMinWidth(buttonWidth);
                deleteButton.setMaxWidth(buttonWidth);

                deleteButton.setOnAction(event -> {
                    Ticket selectedTicket = getTableView().getItems().get(getIndex());
                    Delete.deleteTicket(selectedTicket, ticketTable);
                    editOrDeleteOccurred = true;
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(deleteButton);
                }
            }
        }); 

        ticketTable.getColumns().addAll(ticketTitleColumn, projectColumn, descriptionColumn, editColumn, deleteColumn);
        
        List<Ticket> tickets = getTicketsForProjects(main.connectToDatabase, projectNames);
        

        
        HBox searchBox = new HBox(0); 
        searchBox.setAlignment(Pos.CENTER_RIGHT);
        
        TextField searchField = new TextField();
        searchField.setStyle("-fx-font-size: 13px; -fx-font-family: 'Comic Sans MS';");
        searchField.setPromptText("🔍 Search tickets...");
        searchField.setMaxWidth(180);
             
        ListView<String> searchResults = new ListView<>();
        searchResults.setStyle("-fx-font-size: 12px; -fx-font-family: 'Comic Sans MS';");
        searchResults.setMaxWidth(200);
        searchResults.setMaxHeight(100);
        searchResults.setVisible(false);
        
    
        ticketTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        ObservableList<Ticket> ObservableTicketsData = FXCollections.observableArrayList(tickets);
        ticketTable.setItems(ObservableTicketsData);


        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            performSearch(newValue, ObservableTicketsData, ticketTable, searchResults, main);
        });

        ticketListBox.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                searchField.clear();
                searchResults.setVisible(false);
                ticketTable.setItems(ObservableTicketsData);
                searchPerformed = false;
            }
        });

        
        ticketListBox.setOnMouseClicked(event -> {
            if (searchPerformed) {
                searchField.clear();
                searchResults.setVisible(false);
                ticketTable.setItems(ObservableTicketsData);
                searchPerformed = false;
            }
        });

        Button backButton = new Button("Back");
        backButton.setOnAction(event -> {
            main.startScreen(main.loadProjectNamesFromDatabase());
            if (editOrDeleteOccurred) {
                editOrDeleteOccurred = false;
                return;
            }
        });

        Button cancelSearchButton = new Button("X");
        cancelSearchButton.setOnAction(event -> {
            searchField.clear();
            searchResults.setVisible(false);
            ticketTable.setItems(ObservableTicketsData);
            searchPerformed = false;
        });

     // Put the search field and cancel button in an HBox
        HBox searchFieldBox = new HBox(0);
        searchFieldBox.getChildren().addAll(searchField, cancelSearchButton);

        StackPane searchPane = new StackPane();
        searchPane.getChildren().addAll(searchResults);
        StackPane.setAlignment(searchResults, Pos.TOP_RIGHT);
        
        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(ticketTable, searchResults);
        StackPane.setAlignment(searchResults, Pos.TOP_RIGHT);
        
        searchBox.getChildren().addAll(searchFieldBox);
        
        HBox backBox = new HBox(backButton); 
        backBox.setAlignment(Pos.BASELINE_LEFT); 

        HBox.setHgrow(searchBox, Priority.ALWAYS);
        ticketListBox.setPadding(new Insets(20, 20, 20, 20));

        ticketListBox.getChildren().addAll(searchBox, stackPane, backButton);
        main.projectStage.setScene(new Scene(ticketListBox, 950, 600));
        main.projectStage.setTitle("Ticket List");
        main.projectStage.show();
    }
   
    
    private static List<Ticket> getTicketsForProjects(Connection connection, List<String> projectNames) {
        List<Ticket> tickets = new ArrayList<>();

        try {
            // Fetch tickets from the database for the selected project names
            for (String projectName : projectNames) {
                String query = "SELECT T.title, T.description, P.name AS project_name " +
                        "FROM Tickets T " +
                        "INNER JOIN Projects P ON T.project_name = P.name " +
                        "WHERE P.name = ? COLLATE NOCASE";
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, projectName);
                ResultSet resultSet = preparedStatement.executeQuery();


                while (resultSet.next()) {
//                    System.out.println("  Title: " + resultSet.getString("title") +
//                            ", Description: " + resultSet.getString("description") +
//                            ", Project Name: " + resultSet.getString("project_name"));

                    String title = resultSet.getString("title");
                    String description = resultSet.getString("description");
                    String projectNameForTicket = resultSet.getString("project_name");
                    tickets.add(new Ticket(title, description, projectNameForTicket));
                }

                resultSet.close();
                preparedStatement.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error fetching tickets from the database.");
        }
        return tickets;
    }



    // performSearch method
    private static void performSearch(String query, ObservableList<Ticket> ticketsData,
                                      TableView<Ticket> ticketTable, ListView<String> searchResults, Main main) {
        searchResults.getItems().clear();

        if (query.isEmpty()) {
            searchResults.setVisible(false);
            ticketTable.setVisible(true);
           
        } else {
            searchResults.setVisible(true);
            searchPerformed = true;  // Set searchPerformed to true

            ObservableList<String> searchResultsData = FXCollections.observableArrayList();
            for (Ticket ticket : ticketsData) {
                if (ticket.getTitle().toLowerCase().contains(query.toLowerCase()) ||
                        ticket.getProjectName().toLowerCase().contains(query.toLowerCase())) {
                    String resultString = ticket.getTitle();
                    searchResultsData.add(resultString);
                }
            }

            if (searchResultsData.isEmpty()) {
                searchResults.getItems().add("No results found");
                System.out.println("");
            } else {
                searchResults.setItems(searchResultsData);
            }

            searchResults.setOnMouseClicked(event -> {
                String selectedItem = searchResults.getSelectionModel().getSelectedItem();
                if (selectedItem != null && !selectedItem.equals("No results found")) {
                    int selectedIndex = searchResults.getSelectionModel().getSelectedIndex();
                    Ticket selectedTicket = ticketsData.get(selectedIndex);
                    showEditAndDeleteOptions(selectedTicket, ticketTable, main);
                }
            });
        }
    }

    private static void showEditAndDeleteOptions(Ticket selectedTicket,TableView<Ticket> ticketTable, Main main) {
        Stage editStage = new Stage();
        editStage.initModality(Modality.APPLICATION_MODAL);
        editStage.setTitle("Edit Ticket");

        Label titleLabel = new Label("Title:");
        TextField titleField = new TextField(selectedTicket.getTitle());

        Label descriptionLabel = new Label("Description:");
        TextArea descriptionArea = new TextArea(selectedTicket.getDescription());

        Button saveButton = new Button("Save");
        Button deleteButton = new Button("Delete");

        // Set the action for the save button
        saveButton.setOnAction(event -> {saveTicketChangesToDatabase(titleField.getText(), descriptionArea.getText(), ticketTable,selectedTicket.getTitle(),selectedTicket.getProjectName(), main);
            // Update the ticket with the edited values
            
            ticketTable.refresh();
            showTicketList(main, main.loadProjectNamesFromDatabase());
            // Close the edit stage
            editStage.close();

            // Set the flag to indicate that an edit or delete operation occurred
            editOrDeleteOccurred = true;
        });

        // Set the action for the delete button
        deleteButton.setOnAction(event -> {
            Delete.deleteTicket(selectedTicket, ticketTable);
            editStage.close();

            // Set the flag to indicate that an edit or delete operation occurred
            editOrDeleteOccurred = true;
        });

        VBox editLayout = new VBox(10);
        editLayout.getChildren().addAll(titleLabel, titleField, descriptionLabel, descriptionArea, saveButton, deleteButton);

        Scene editScene = new Scene(editLayout, 400, 250);
        editStage.setScene(editScene);
        editStage.showAndWait();
    }

	static void saveTicketChangesToDatabase(String newTicket, String newDescription, TableView<Ticket> ticketTable, String existingTicketName, String existingProjectName,Main main) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:quillqube.db")) {
            
        	if (connection != null) {
        		
                String updateTicketQuery = "UPDATE Tickets SET title = ?, description = ? WHERE project_name = ? AND title = ?";

                try (PreparedStatement preparedStatement = connection.prepareStatement(updateTicketQuery)) {
                    preparedStatement.setString(1, newTicket);
                    preparedStatement.setString(2, newDescription);
                    
					preparedStatement.setString(3, existingProjectName);
					preparedStatement.setString(4, existingTicketName);

                    // Execute the update query
                    preparedStatement.executeUpdate();

                    ticketTable.refresh();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
	public static void deleteTicketFromDatabase(TableView<Ticket> ticketTable, String existingTicketName, String existingProjectName,Main main) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:quillqube.db")) {
            
        	if (connection != null) {
                String deleteQuery = "DELETE FROM Tickets WHERE title = ?, description = ? WHERE project_name = ? AND title = ?";

                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
                    
					preparedStatement.setString(1, existingProjectName);
					preparedStatement.setString(2, existingTicketName);

                    // Execute the update query
                    preparedStatement.executeUpdate();

                    ticketTable.refresh();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
