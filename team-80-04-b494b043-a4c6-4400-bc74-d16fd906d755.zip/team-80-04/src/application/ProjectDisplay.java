package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ProjectDisplay {
	
    private TextArea descriptionTextArea;
    private TextField nameTextField;
    private DatePicker dateField;

	public void openProjectDetails(ProjectDataController proj, Main main) {
		
		Label nameLabel = new Label("Name: " );
        nameTextField = new TextField(proj.getName());
        
        HBox nameHBox = new HBox(10, nameLabel, nameTextField);

        Label descriptionLabel = new Label("Description");
        descriptionTextArea = new TextArea(proj.getDescription());
        
        VBox descHBox = new VBox(10, descriptionLabel, descriptionTextArea);
        
        Label dateLabel = new Label("Date: ");
        dateField = new DatePicker();
        dateField.setValue(LocalDate.now());
        
        HBox dateHBox = new HBox(10, dateLabel, dateField);
        
        VBox detailsLayout = new VBox(10, nameHBox, dateHBox, descHBox);
        Scene detailsScene = new Scene(detailsLayout, 500, 300);
        Stage primaryStage = new Stage();
        
        Button saveButton = new Button("Save");
        Button deleteButton = new Button("Delete This Project");
        saveButton.setOnAction(e -> {saveDescriptionToDatabase(nameTextField.getText(), descriptionTextArea.getText(), dateField.getValue().toString(), proj.getId()); 
        		primaryStage.close();
        		ProjectList.showProjectList(main);
        });
        
        deleteButton.setOnAction(e -> {
        	deleteProjectFromDatabase(main, proj.getName());
        	primaryStage.close();
        	ProjectList.showProjectList(main);
        });
        detailsLayout.getChildren().add(saveButton);
        detailsLayout.getChildren().add(deleteButton);
        detailsLayout.setPadding(new Insets(10, 10, 10, 10));
        

       
        primaryStage.setScene(detailsScene);
        primaryStage.setTitle("Project Details");
        primaryStage.show();
	}
	
	
	private void saveDescriptionToDatabase(String newName, String newDescription, String newDate, int id) {
        // Assuming you have a database connection
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:quillqube.db")) {
            String query = "UPDATE projects SET name = ?, description = ?, startDate = ? WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, newName);
                preparedStatement.setString(2, newDescription);
                preparedStatement.setString(3, newDate);
                preparedStatement.setInt(4, id);
                // Execute the update query
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }
	
	private void deleteProjectFromDatabase(Main main, String projectToDelete) {
	    try {
	        // Prepare a query to delete tickets associated with the project
	        String deleteTicketsQuery = "DELETE FROM Tickets WHERE project_name = ?";
	        PreparedStatement deleteTicketsStatement = main.connectToDatabase.prepareStatement(deleteTicketsQuery);
	        deleteTicketsStatement.setString(1, projectToDelete);

	        // Execute the delete query for tickets
	        deleteTicketsStatement.executeUpdate();

	        // Close the tickets statement
	        deleteTicketsStatement.close();

	        // Prepare a query to get ticket names associated with the project
	        String selectTicketNamesQuery = "SELECT title FROM Tickets WHERE project_name = ?";
	        PreparedStatement selectTicketNamesStatement = main.connectToDatabase.prepareStatement(selectTicketNamesQuery);
	        selectTicketNamesStatement.setString(1, projectToDelete);

	        // Execute the select query for ticket names
	        ResultSet ticketNamesResultSet = selectTicketNamesStatement.executeQuery();

	        // Prepare a query to delete comments associated with each ticket
	        String deleteCommentsQuery = "DELETE FROM Comments WHERE ticket_name = ?";
	        PreparedStatement deleteCommentsStatement = main.connectToDatabase.prepareStatement(deleteCommentsQuery);

	        // Loop through the ticket names and delete comments
	        while (ticketNamesResultSet.next()) {
	            String ticketName = ticketNamesResultSet.getString("title");
	            deleteCommentsStatement.setString(1, ticketName);
	            deleteCommentsStatement.executeUpdate();
	        }

	        // Close the statements and result set
	        selectTicketNamesStatement.close();
	        ticketNamesResultSet.close();
	        deleteCommentsStatement.close();

	        // Prepare a query to delete the project
	        String deleteProjectQuery = "DELETE FROM Projects WHERE name = ?";
	        PreparedStatement deleteProjectStatement = main.connectToDatabase.prepareStatement(deleteProjectQuery);
	        deleteProjectStatement.setString(1, projectToDelete);

	        // Execute the delete query for the project
	        deleteProjectStatement.executeUpdate();

	        // Close the project statement
	        deleteProjectStatement.close();

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}




}
